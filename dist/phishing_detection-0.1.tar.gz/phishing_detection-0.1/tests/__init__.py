# -*- coding: utf-8 -*-

"""Unit test package for phishing_detection."""
