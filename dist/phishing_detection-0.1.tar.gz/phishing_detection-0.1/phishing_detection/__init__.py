# -*- coding: utf-8 -*-

"""Top-level package for Phishing Detection Using Random Forest."""

__author__ = """Abhishek Parmar"""
__email__ = 'abhishek.parmar@somaiya.edu'
__version__ = '0.1'
