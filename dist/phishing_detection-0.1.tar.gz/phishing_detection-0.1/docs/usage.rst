=====
Usage
=====

To use Phishing Detection Using Random Forest in a project::

    import phishing_detection
